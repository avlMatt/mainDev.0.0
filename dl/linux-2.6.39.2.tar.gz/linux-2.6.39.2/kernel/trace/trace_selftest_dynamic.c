#include "trace.h"

int DYN_FTRACE_TEST_NAME(void)
{
	/* used to call mcount */
	return 0;
}
